# Drive
This library provides basic functionalities such as:
moveForward(int speed)
moveBackward(int speed)
turnRight(int speed)
turnLeft(int speed)
moveforwardLeft (int speed)
stopMoving(int speed)
moveforwardRight(int speed)
Speed: 0-1024
More functionalites would be added over time.
